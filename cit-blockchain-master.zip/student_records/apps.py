from django.apps import AppConfig


class StudentRecordsConfig(AppConfig):
    name = 'student_records'
