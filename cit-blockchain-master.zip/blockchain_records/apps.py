from django.apps import AppConfig


class BlockchainRecordsConfig(AppConfig):
    name = 'blockchain_records'
